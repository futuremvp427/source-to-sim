# Integrated four-wallet paper study

Stage: TERMINAL
Exact run: https://github.com/futuremvp427/source-to-sim/actions/runs/SYNTHETIC-LIFECYCLE-FIXTURE-NOT-A-STUDY-RUN
Code: `2f35c71992d35645ae1ac445ccdc45fb15a21cac`; protocol SHA-256: `f66cb42c7006238fb4155ed455dda8a18007116f401fd6cfbeca671199cb1adf`.
Actual measured interval: 2026-10-18T19:24:00+00:00 to 2026-10-20T19:24:01+00:00.
Planned entries end 2026-10-20T19:24:00+00:00; bounded drain ends 2026-10-22T19:24:00+00:00.

Four independent fictional $1,000 accounts; no combined realizable portfolio. Source profits are not follower returns.

| Wallet | Completed net after modeled fees | Stress net | Completed distinct US markets | Open markets | Screen |
| --- | ---: | ---: | ---: | ---: | --- |
| ic4cream | $-5.07 | $-5.47 | 1 | 0 | INSUFFICIENT_TRADES/COVERAGE |
| alwaysfade | N/A | N/A | 0 | 0 | INSUFFICIENT_TRADES/COVERAGE |
| monkeymashingkeyboard | N/A | N/A | 0 | 0 | INSUFFICIENT_TRADES/COVERAGE |
| para-Vision | N/A | N/A | 0 | 0 | INSUFFICIENT_TRADES/COVERAGE |

Completed net excludes unresolved exposure; N/A is not zero P&L. No durable or live-money profitability is established.

## ic4cream

Actual simulated contracts bought / sold / settled: 25.00 / 15.00 / 10.00.
Observed drawdown: $5.07; complete scheduled marks: 0.10%; held-inventory marks: 100.00%. Missing marks cannot establish the true maximum drawdown.
Source coverage elapsed / full planned collection: 0.13% / 0.13%.
Source-to-fill latency seconds: `{"count": 3, "maximum": 30.0, "mean": 30.0, "minimum": 30.0}`.
Fill/skip reasons: `{"no_fresh_confirmed_buy_for_net_side": 2}`.
Event-cluster bootstrap lower 2.5% stress-mean percentile: None.
Unresolved positions and scheduled dates: `[]`.

## alwaysfade

Actual simulated contracts bought / sold / settled: 0 / 0 / 0.
Observed drawdown: $0.00; complete scheduled marks: 0.10%; held-inventory marks: N/A (no held exposure). Missing marks cannot establish the true maximum drawdown.
Source coverage elapsed / full planned collection: 0.13% / 0.13%.
Source-to-fill latency seconds: `{"count": 0, "maximum": null, "mean": null, "minimum": null}`.
Fill/skip reasons: `{}`.
Event-cluster bootstrap lower 2.5% stress-mean percentile: None.
Unresolved positions and scheduled dates: `[]`.

## monkeymashingkeyboard

Actual simulated contracts bought / sold / settled: 0 / 0 / 0.
Observed drawdown: $0.00; complete scheduled marks: 0.10%; held-inventory marks: N/A (no held exposure). Missing marks cannot establish the true maximum drawdown.
Source coverage elapsed / full planned collection: 0.13% / 0.13%.
Source-to-fill latency seconds: `{"count": 0, "maximum": null, "mean": null, "minimum": null}`.
Fill/skip reasons: `{}`.
Event-cluster bootstrap lower 2.5% stress-mean percentile: None.
Unresolved positions and scheduled dates: `[]`.

## para-Vision

Actual simulated contracts bought / sold / settled: 0 / 0 / 0.
Observed drawdown: $0.00; complete scheduled marks: 0.10%; held-inventory marks: N/A (no held exposure). Missing marks cannot establish the true maximum drawdown.
Source coverage elapsed / full planned collection: 0.13% / 0.13%.
Source-to-fill latency seconds: `{"count": 0, "maximum": null, "mean": null, "minimum": null}`.
Fill/skip reasons: `{}`.
Event-cluster bootstrap lower 2.5% stress-mean percentile: None.
Unresolved positions and scheduled dates: `[]`.

Short screen only: same-game/day dependence, recent-winner selection and four simultaneous comparisons remain limitations. A positive sample is not proof of a lasting edge; fewer than 30 markets or inadequate coverage remains insufficient.
